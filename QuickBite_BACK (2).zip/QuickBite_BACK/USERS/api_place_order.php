<?php
session_start();
header("Content-Type: application/json");
require '../db.php';

$data = json_decode(file_get_contents("php://input"), true);

$user_id = $_SESSION['user_id'];
$items = $data['items'];
$total = $data['total'];
$address = $data['address'];

if (!$user_id || empty($items)) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

// Insert order
$stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, delivery_address) VALUES (?, ?, ?)");
$stmt->bind_param("ids", $user_id, $total, $address);
$stmt->execute();

$order_id = $stmt->insert_id;

// Insert order items
$itemStmt = $conn->prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, price_at_time) VALUES (?, ?, ?, ?)");

foreach ($items as $item) {
    $itemStmt->bind_param("iiid", $order_id, $item['menu_item_id'], $item['quantity'], $item['price']);
    $itemStmt->execute();
}

echo json_encode(['success' => true, 'order_id' => $order_id]);
?>
