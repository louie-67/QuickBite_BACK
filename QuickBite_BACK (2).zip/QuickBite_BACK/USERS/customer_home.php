<?php
// Start the session to access $_SESSION variables
session_start();

// 1. Check if the user is NOT logged in
if (!isset($_SESSION["user_id"]) || !isset($_SESSION["role"])) {
    // Redirect to login.html (one directory up: ../)
    header("Location: ../login.html");
    exit;
}

// 2. Check if the logged-in user is NOT a customer
if ($_SESSION["role"] !== "customer") {
    // Redirect them if they don't have the customer role
    header("Location: ../login.html");
    exit;
}

// If they passed both checks, they are a logged-in customer.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickBite | Menu & Orders</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #ff6a4d; /* Bright Red-Orange */
            --secondary-color: #ffb85c; /* Warm Orange */
            --background-color: #f8f8f8;
            --text-color: #333;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
            padding-top: 60px; /* Space for fixed header */
        }

        /* --- HEADER / NAVIGATION --- */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 60px;
            background: var(--primary-color);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 25px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
            letter-spacing: -1px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
            transition: opacity 0.2s;
        }
        
        .nav-links a:hover {
            opacity: 0.8;
        }

        /* --- MAIN CONTAINER --- */
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }

        /* --- WELCOME & SEARCH BAR --- */
        .welcome-section {
            padding: 30px 0;
            text-align: center;
            background: linear-gradient(90deg, #ffc596, var(--secondary-color));
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 8px 15px rgba(255, 106, 77, 0.1);
        }
        
        .welcome-section h2 {
            font-size: 32px;
            color: #555;
            margin-bottom: 15px;
        }

        .search-bar input {
            width: 80%;
            max-width: 600px;
            padding: 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05);
            transition: border-color 0.3s;
        }
        
        .search-bar input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        /* --- MENU GRID --- */
        h3.section-title {
            font-size: 26px;
            color: var(--primary-color);
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 10px;
            margin-bottom: 25px;
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .menu-item {
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
        }

        .menu-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(255, 106, 77, 0.3);
        }

        .item-image {
            height: 200px;
            width: 100%;
            background-color: #eee; /* Placeholder background */
            /* Add your actual food image here */
            background-size: cover;
            background-position: center;
        }
        
        .item-content {
            padding: 20px;
        }
        
        .item-content h4 {
            font-size: 20px;
            color: var(--text-color);
            margin-bottom: 5px;
        }
        
        .item-content p {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }

        .item-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }
        
        .price {
            font-size: 22px;
            font-weight: 700;
            color: var(--primary-color);
        }

        .add-to-cart {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.2s;
        }
        
        .add-to-cart:hover {
            background-color: #e5573d;
        }
        
        /* --- FOOTER --- */
        .footer {
            text-align: center;
            padding: 20px;
            margin-top: 40px;
            border-top: 1px solid #ddd;
            color: #999;
            font-size: 14px;
        }

    </style>
</head>
<body>

    <header class="header">
        <div class="logo">QuickBite</div>
        <nav class="nav-links">
            <a href="#"><i class="fas fa-home"></i> Home</a>
            <a href="#"><i class ="fas fa-cart"></i>Cart</a>
            <a href="#"><i class="fas fa-history"></i> Orders</a>
            <a href="#"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </header>

    <div class="container">
        
        <section class="welcome-section">
            <h2>Welcome Back, Customer! 👋</h2>
            <div class="search-bar">
                <input type="text" placeholder="Search for burgers, pizzas, or drinks...">
            </div>
        </section>

        <section class="menu">
            <h3 class="section-title">Today's Hot Picks 🔥</h3>
            
            <div class="menu-grid">
                
                <div class="menu-item">
                    <div class="item-image" style="background-image: url('assets/images/burger.jpg');"></div>
                    <div class="item-content">
                        <h4>Juicy Beef Burger</h4>
                        <p>Our signature burger with melted cheddar and secret sauce.</p>
                        <div class="item-footer">
                            <span class="price">$12.99</span>
                            <button class="add-to-cart"><i class="fas fa-plus"></i> Add to Cart</button>
                        </div>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-image" style="background-image: url('assets/images/pizza.jpg');"></div>
                    <div class="item-content">
                        <h4>Pepperoni Feast Pizza</h4>
                        <p>Loaded with spicy pepperoni and mozzarella cheese.</p>
                        <div class="item-footer">
                            <span class="price">P285.99</span>
                            <button class="add-to-cart"><i class="fas fa-plus"></i> Add to Cart</button>
                        </div>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-image" style="background-image: url('assets/images/fries.jpg');"></div>
                    <div class="item-content">
                        <h4>Crispy Gold Fries</h4>
                        <p>Perfectly salted and served hot with your choice of dip.</p>
                        <div class="item-footer">
                            <span class="price">P55.50</span>
                            <button class="add-to-cart"><i class="fas fa-plus"></i> Add to Cart</button>
                        </div>
                    </div>
                </div>
                
                <div class="menu-item">
                    <div class="item-image" style="background-image: url('assets/images/cola.jpg');"></div>
                    <div class="item-content">
                        <h4>Refreshing Cola</h4>
                        <p>A cold, fizzy beverage to complete your meal.</p>
                        <div class="item-footer">
                            <span class="price">P45.00</span>
                            <button class="add-to-cart"><i class="fas fa-plus"></i> Add to Cart</button>
                        </div>
                    </div>
                </div>
                
            </div>
            
        </section>

    </div>

    <footer class="footer">
        &copy; <?php echo date("Y"); ?> QuickBite Food Delivery. All rights reserved.
    </footer>

    <script type="module" src=".\js\cart.js"></script>
</body>
</html>