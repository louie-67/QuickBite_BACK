<?php
header("Content-Type: application/json");
require '../db.php';

$query = $conn->query("
    SELECT o.*, u.username 
    FROM orders o 
    JOIN users u ON o.user_id = u.id
    ORDER BY o.order_date DESC
");

$orders = [];

while ($row = $query->fetch_assoc()) {
    $order_id = $row['id'];

    // Fetch items
    $itemQuery = $conn->query("
        SELECT oi.*, mi.name 
        FROM order_items oi
        JOIN menu_items mi ON oi.menu_item_id = mi.id
        WHERE oi.order_id = $order_id
    ");

    $items = [];
    while ($item = $itemQuery->fetch_assoc()) {
        $items[] = [
            'name' => $item['name'],
            'quantity' => $item['quantity']
        ];
    }

    $orders[] = [
        'id' => $order_id,
        'student' => $row['username'],
        'items' => implode(", ", array_map(fn($i) => $i['name']." x ".$i['quantity'], $items)),
        'amount' => (float)$row['total_amount'],
        'status' => strtoupper($row['status'])
    ];
}

echo json_encode(['orders' => $orders]);
